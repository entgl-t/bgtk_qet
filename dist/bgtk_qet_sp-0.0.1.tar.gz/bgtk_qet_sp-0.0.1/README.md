# Create package
From **bgtk-qet** directory:
`python3 -m build`
# Installation
Copy **dist/** files or clone project and:
`pip install ./dist/bgtk_qet_sp-0.0.1.tar.gz`